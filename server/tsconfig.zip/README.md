## Описание

API сервер для тестового задания

## Установка

```bash
$ npm install
```

## Запуск

```bash
# development
$ npm run start

# watch mode
$ npm run start:dev

# production mode
$ npm run start:prod
```

## Сервер

```bash
http://localhost:4000/api
```
